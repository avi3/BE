/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package person;

/**
 *Represents a user who is not a friend
 * @author g
 */
public interface friendInterface {
/**
 * Make a comment of friend
      * @param myCommant
 */
    void putComments(String myCommant);//להחליף את סטרינג להערה
}